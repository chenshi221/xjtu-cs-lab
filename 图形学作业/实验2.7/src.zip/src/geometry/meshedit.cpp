#include "halfedge.h"

#include <set>
#include <map>
#include <vector>
#include <string>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <spdlog/spdlog.h>

using Eigen::Matrix3f;
using Eigen::Matrix4f;
using Eigen::Vector3f;
using Eigen::Vector4f;
using std::optional;
using std::set;
using std::size_t;
using std::string;
using std::unordered_map;
using std::vector;

HalfedgeMesh::EdgeRecord::EdgeRecord(unordered_map<Vertex*, Matrix4f>& vertex_quadrics, Edge* e)
    : edge(e)
{
    (void)vertex_quadrics;
    optimal_pos = Vector3f(0.0f, 0.0f, 0.0f);
    cost        = 0.0f;
}

bool operator<(const HalfedgeMesh::EdgeRecord& a, const HalfedgeMesh::EdgeRecord& b)
{
    return a.cost < b.cost;
}

optional<Edge*> HalfedgeMesh::flip_edge(Edge* e)
{
    // �Ǳ߽��
    if (!e->on_boundary()) {
        // Ҫ�õ��İ��
        Halfedge* h     = e->halfedge;
        Halfedge* h_inv = h->inv;
        Halfedge* h_2_3 = h->next;
        Halfedge* h_3_1 = h_2_3->next;
        Halfedge* h_1_4 = h_inv->next;
        Halfedge* h_4_2 = h_1_4->next;
        // v3 and v4 are vertices opposite the edge
        Vertex* v1 = h->from;
        Vertex* v2 = h_inv->from;
        Vertex* v3 = h_3_1->from;
        Vertex* v4 = h_4_2->from;
        // Ҫ�õ�����Ƭ
        Face* f1 = h->face;
        Face* f2 = h_inv->face;
        // �������Ӹ�����Ԫ��
        // ����h
        h->next = h_3_1;
        h->prev = h_1_4;
        h->from = v4;
        // ����h->inv
        h_inv->next = h_4_2;
        h_inv->prev = h_2_3;
        h_inv->from = v3;
        // ����������󶨵İ��
        f1->halfedge = h;
        f2->halfedge = h_inv;
        // ������������󶨵İ��
        v1->halfedge = h_1_4;
        v2->halfedge = h_2_3;
        // �������
        h_2_3->set_neighbors(h_inv, h_4_2, h_2_3->inv, h_2_3->from, h_2_3->edge, f2);
        h_4_2->set_neighbors(h_2_3, h_inv, h_4_2->inv, h_4_2->from, h_4_2->edge, f2);
        h_3_1->set_neighbors(h_1_4, h, h_3_1->inv, h_3_1->from, h_3_1->edge, f1);
        h_1_4->set_neighbors(h, h_3_1, h_1_4->inv, h_1_4->from, h_1_4->edge, f1);

        return e;
    }

    else {
        return std::nullopt;
    }
}

optional<Vertex*> HalfedgeMesh::split_edge(Edge* e)
{
    if (!e->on_boundary()) {
        // ��ȡ4������
        Vertex* v1 = e->halfedge->from;
        Vertex* v2 = e->halfedge->inv->from;
        Vertex* v3 = e->halfedge->prev->from;
        Vertex* v4 = e->halfedge->inv->prev->from;

        // ��ȡ��
        Halfedge* h     = e->halfedge;
        Halfedge* h_inv = e->halfedge->inv;
        Halfedge* h23   = h->next;
        Halfedge* h31   = h->prev;
        Halfedge* h42   = h_inv->prev;
        Halfedge* h14   = h_inv->next;

        // ��ȡ��
        Face* f01 = h23->face;
        Face* f02 = h42->face;

        // ����һ���µĶ��㣬��Ϊ�ָ��
        Vertex* v5 = new_vertex();
        v5->pos    = (v2->pos + v1->pos) / 2;

        // �Ա����ıߴ���4����
        Face* f1     = new_face();
        f1->halfedge = h14;
        Face* f2     = new_face();
        f2->halfedge = h23;
        Face* f3     = new_face();
        f3->halfedge = h31;
        Face* f4     = new_face();
        f4->halfedge = h42;

        // �������
        Halfedge* h15 = new_halfedge();
        Halfedge* h51 = new_halfedge();
        Halfedge* h25 = new_halfedge();
        Halfedge* h52 = new_halfedge();
        Halfedge* h35 = new_halfedge();
        Halfedge* h53 = new_halfedge();
        Halfedge* h45 = new_halfedge();
        Halfedge* h54 = new_halfedge();

        // ������
        Edge* e1     = new_edge();
        e1->halfedge = h15;
        Edge* e2     = new_edge();
        e2->halfedge = h25;
        Edge* e3     = new_edge();
        e3->halfedge = h35;
        Edge* e4     = new_edge();
        e4->halfedge = h45;

        // ���ð��
        h15->set_neighbors(h53, h31, h51, v1, e1, f3);
        h51->set_neighbors(h14, h45, h15, v5, e1, f1);
        h25->set_neighbors(h54, h42, h52, v2, e2, f4);
        h52->set_neighbors(h23, h35, h25, v5, e2, f2);
        h35->set_neighbors(h52, h23, h53, v3, e3, f2);
        h53->set_neighbors(h31, h15, h35, v5, e3, f3);
        h45->set_neighbors(h51, h14, h54, v4, e4, f1);
        h54->set_neighbors(h42, h25, h45, v5, e4, f4);

        // ������Χ4��
        h23->set_neighbors(h35, h52, h23->inv, v2, h23->edge, f2);
        h31->set_neighbors(h15, h53, h31->inv, v3, h31->edge, f3);
        h14->set_neighbors(h45, h51, h14->inv, v1, h14->edge, f1);
        h42->set_neighbors(h25, h54, h42->inv, v4, h42->edge, f4);

        v5->halfedge = h51;

        // �ĸ����������
        v1->halfedge = h15;
        v2->halfedge = h25;
        v3->halfedge = h35;
        v4->halfedge = h45;

        // ɾ������Ҫ��Ԫ��

        erase(f01);
        erase(f02);
        erase(e);
        erase(h_inv);
        erase(h);

        return v5;
    } else {
        return std::nullopt;
    }
}

optional<Vertex*> HalfedgeMesh::collapse_edge(Edge* e)
{
    if (!e->on_boundary()) {
        // ��ȡ���
        Halfedge* h     = e->halfedge;
        Halfedge* h_inv = h->inv;

        // ��ȡ����
        Vertex* v1 = h->from;
        Vertex* v2 = h_inv->from;
        Vertex* v3 = h->prev->from;
        Vertex* v4 = h_inv->prev->from;

        // ��ȫ���

        if (v1->degree() <= 3 || v2->degree() <= 3) {
            return std::nullopt;
        }

        //
        v1->pos = (v1->pos + v2->pos) / 2;

        //
        Halfedge* temp_h = h->inv;
        while (temp_h->prev->inv != h->inv) {
            temp_h       = temp_h->prev->inv;
            temp_h->from = v1;
        }

        h->prev->inv->set_neighbors(h->prev->inv->next, h->prev->inv->prev, h->next->inv, v1,
                                    h->prev->inv->edge, h->prev->inv->face);
        h->next->inv->set_neighbors(h->next->inv->next, h->next->inv->prev, h->prev->inv, v3,
                                    h->prev->inv->edge, h->next->inv->face);
        h->prev->inv->edge->halfedge = h->prev->inv;

        h->inv->next->inv->set_neighbors(h->inv->next->inv->next, h->inv->next->inv->prev,
                                         h->inv->prev->inv, v4, h->inv->next->inv->edge,
                                         h->inv->next->inv->face);
        h->inv->prev->inv->set_neighbors(h->inv->prev->inv->next, h->inv->prev->inv->prev,
                                         h->inv->next->inv, v1, h->inv->next->inv->edge,
                                         h->inv->prev->inv->face);
        h->inv->next->inv->edge->halfedge = h->inv->next->inv;

        // ����Ķ�Ӧ���
        v1->halfedge = h->prev->inv;
        v3->halfedge = h->next->inv;
        v4->halfedge = h->inv->next->inv;
        // ɾ������Ԫ��

        erase(h->inv->prev->edge);
        erase(h->inv->prev->face);
        erase(h->inv->prev);
        erase(h->inv->next->edge);
        erase(h->inv->next);
        erase(h->prev->edge);
        erase(h->prev->face);
        erase(h->prev);
        erase(h->next->edge);
        erase(h->next);
        erase(v2);
        erase(h->inv);
        erase(h->edge);
        erase(h);
        return v1;
    } else if (e->on_boundary()) {
        Halfedge* h;
        if (e->halfedge->is_boundary()) {
            h = e->halfedge->inv;
        } else {
            h = e->halfedge;
        }
        Vertex* v1 = h->from;
        Vertex* v2 = h->next->from;
        Vertex* v3 = h->prev->from;

        // �ƶ�v1
        v1->pos = (v1->pos + v2->pos) / 2;

        // ����v2�����а��
        Halfedge* temp_h = h->next;
        while (true) {
            temp_h->from = v1;
            if (temp_h->edge->on_boundary()) {
                break;
            }
            temp_h = temp_h->inv->next;
        }
        h->prev->inv->set_neighbors(h->prev->inv->next, h->prev->inv->prev, h->next->inv, v1,
                                    h->prev->inv->edge, h->prev->inv->face);
        h->next->inv->set_neighbors(h->next->inv->next, h->next->inv->prev, h->prev->inv, v3,
                                    h->prev->inv->edge, h->next->inv->face);
        h->prev->inv->edge->halfedge = h->prev->inv;

        // �󶨶�����

        v1->halfedge = h->prev->inv;
        v3->halfedge = h->next->inv;

        // ɾ������Ԫ��
        erase(h->face);
        erase(h->next->edge);
        erase(h->next);
        erase(h->prev);
        erase(h->edge);
        erase(h->inv);
        erase(v2);
        erase(h);
        return v1;
    } else {
        return std::nullopt;
    }
}

void HalfedgeMesh::loop_subdivide()
{
    optional<HalfedgeMeshFailure> check_result = validate();
    if (check_result.has_value()) {
        return;
    }
    logger->info("subdivide object {} (ID: {}) with Loop Subdivision strategy", object.name,
                 object.id);
    logger->info("original mesh: {} vertices, {} faces in total, {} edges in total", vertices.size,
                 faces.size, edges.size);

    // ʹ�� Loop ϸ�ֹ�������������������ж������λ�ã��������Ǵ洢�� Vertex::new_pos �С�

    for (Vertex* v = vertices.head; v != nullptr; v = v->next_node) {
        int num      = 0;
        Vector3f sum = Vector3f(0.0f, 0.0f, 0.0f);
        Halfedge* h  = v->halfedge;
        do {
            sum += h->inv->from->pos;
            h = h->prev->inv;
            num++;
        } while (h != v->halfedge);
        if (num <= 3) {
            v->new_pos = (1 - 3.0f * 3.0f / 16.0f) * v->pos + 3.0f / 16.0f * sum;
        } else {
            float u    = 3.0f / (8.0f * num);
            float w    = 1.0f - num * u;
            v->new_pos = u * sum + w * v->pos;
        }
    }

    // ������߹�����ϸ�ֺ󶥵�λ�ã��������Ǵ洢�� Edge::new_pos �С�

    for (Edge* e = edges.head; e != nullptr; e = e->next_node) {
        e->new_pos =
            3.0f / 8.0f * (e->halfedge->from->pos + e->halfedge->inv->from->pos) +
            1.0f / 8.0f *
                (e->halfedge->next->next->from->pos + e->halfedge->inv->next->next->from->pos);
    }

    // ���¾ɶ���λ��

    for (Vertex* v = vertices.head; v != nullptr; v = v->next_node) {
        v->pos = v->new_pos;
    }

    // ��¼ԭʼ���������һλ

    Vertex* last_vertex = vertices.tail;
    Edge* last_edge     = edges.tail;

    // ����ÿ����ֱ��ԭʼ���һ����

    for (Edge* e = edges.head; e != last_edge->next_node;) {
        // split_edge(e)������e������Ҫ�ȼ�¼��һ����
        Edge* temp_e      = e->next_node;
        Vector3f temp_pos = e->new_pos;
        // ����
        std::optional<Vertex*> v_opt = split_edge(e);
        // ����������
        v_opt.value()->pos = temp_pos;
        // ����ͨ���ָ�ԭʼ�����еı߶�������ϸ�ֺ�����±ߣ�ͨ������ Edge::is_new ������ʵ�֡�
        v_opt.value()->halfedge->edge->is_new                  = false;
        v_opt.value()->halfedge->prev->edge->is_new            = true;
        v_opt.value()->halfedge->prev->inv->prev->edge->is_new = false;
        v_opt.value()->halfedge->inv->next->edge->is_new       = true;

        e = temp_e;
    }

    // ����½��Ķ���

    for (Vertex* v = last_vertex; v != nullptr; v = v->next_node) {
        v->is_new = true;
    }

    // ��ת�½��ıߣ�����ת�ı��и��ص㣬��һ����һ��������һ���½��Ķ��㣬��һ��������һ��ԭʼ����
    // ͬʱ��Ҫ��ת�ı߱����������½��ı߰�Χ�ţ��������Ǳ��������½��Ķ��㣬Ȼ������������бߣ��ҵ����������ı�

    for (Vertex* v = last_vertex; v != nullptr; v = v->next_node) {
        // ���ҵ�һ��half_new��Ϊ���
        Halfedge* h = v->halfedge;
        while (h->edge->is_new) {
            h = h->prev->inv;
        }
        Halfedge* h_start = h;
        h                 = h->prev->inv;
        while (h != h_start) {
            if (h->edge->is_new && h->prev->edge->is_new && h->prev->inv->prev->edge->is_new) {
                Halfedge* temp = h->prev->inv->prev->inv;
                flip_edge(h->prev->edge);
                h = temp;
            } else {
                h = h->prev->inv;
            }
        }
    }

    // �������½��Ķ����is_new��������Ϊfalse

    for (Vertex* v = vertices.head; v != nullptr; v = v->next_node) {
        v->is_new = false;
    }

    // �����еıߵ�is_new��������Ϊfalse

    for (Edge* e = edges.head; e != nullptr; e = e->next_node) {
        e->is_new = false;
    }

    global_inconsistent = true;
    logger->info("original mesh: {} vertices, {} faces in total, {} edges in total", vertices.size,
                 faces.size, edges.size);
    logger->info("Loop Subdivision done");
    logger->info("");
    validate();
}

void HalfedgeMesh::simplify()
{
    optional<HalfedgeMeshFailure> check_result = validate();
    if (check_result.has_value()) {
        return;
    }
    logger->info("simplify object {} (ID: {})", object.name, object.id);
    logger->info("original mesh: {} vertices, {} faces", vertices.size, faces.size);
    unordered_map<Vertex*, Matrix4f> vertex_quadrics;
    unordered_map<Face*, Matrix4f> face_quadrics;
    unordered_map<Edge*, EdgeRecord> edge_records;
    set<EdgeRecord> edge_queue;

    // Compute initial quadrics for each face by simply writing the plane equation
    // for the face in homogeneous coordinates. These quadrics should be stored
    // in face_quadrics

    // -> Compute an initial quadric for each vertex as the sum of the quadrics
    //    associated with the incident faces, storing it in vertex_quadrics

    // -> Build a priority queue of edges according to their quadric error cost,
    //    i.e., by building an Edge_Record for each edge and sticking it in the
    //    queue. You may want to use the above PQueue<Edge_Record> for this.

    // -> Until we reach the target edge budget, collapse the best edge. Remember
    //    to remove from the queue any edge that touches the collapsing edge
    //    BEFORE it gets collapsed, and add back into the queue any edge touching
    //    the collapsed vertex AFTER it's been collapsed. Also remember to assign
    //    a quadric to the collapsed vertex, and to pop the collapsed edge off the
    //    top of the queue.

    logger->info("simplified mesh: {} vertices, {} faces", vertices.size, faces.size);
    logger->info("simplification done\n");
    global_inconsistent = true;
    validate();
}

void HalfedgeMesh::isotropic_remesh()
{
    optional<HalfedgeMeshFailure> check_result = validate();
    if (check_result.has_value()) {
        return;
    }
    logger->info("remesh the object {} (ID: {}) with strategy Isotropic Remeshing", object.name,
                 object.id);
    logger->info("original mesh: {} vertices,{} edges {} faces", vertices.size, edges.size,
                 faces.size);

    logger->info("remeshed mesh: {} vertices, {} faces\n", vertices.size, faces.size);
    global_inconsistent = true;
    validate();
}
