#include "solver.h"

#include <Eigen/Core>

using Eigen::Vector3f;

// External Force does not changed.

// Function to calculate the derivative of KineticState
KineticState derivative(const KineticState& state)
{
    return KineticState(state.velocity, state.acceleration, Eigen::Vector3f(0, 0, 0));
}

// Function to perform a single Forward Euler step
KineticState forward_euler_step([[maybe_unused]] const KineticState& previous,
                                const KineticState& current)
{
    // ʹ��ŷ��ǰ����ּ�����һ��״̬
    Vector3f new_velocity = current.velocity + current.acceleration * time_step;
    Vector3f new_position = current.position + current.velocity * time_step;

    // �����������µ�״̬
    KineticState next(new_position, new_velocity, current.acceleration);
    return next;
}

// Function to perform a single Runge-Kutta step
KineticState runge_kutta_step([[maybe_unused]] const KineticState& previous,
                              const KineticState& current)
{
    // Runge-Kutta coefficients
    const float dt      = time_step; // ʱ�䲽��

    // Intermediate steps
    Vector3f k1v = current.acceleration * dt; // ���� k1 ���ٶ�����
    Vector3f k1p = current.velocity * dt;     // ���� k1 ��λ������

    Vector3f k2v = (current.acceleration + k1v * 0.5f) * dt; // ���� k2 ���ٶ�����
    Vector3f k2p = (current.velocity + k1p * 0.5f) * dt;     // ���� k2 ��λ������

    Vector3f k3v = (current.acceleration + k2v * 0.5f) * dt; // ���� k3 ���ٶ�����
    Vector3f k3p = (current.velocity + k2p * 0.5f) * dt;     // ���� k3 ��λ������

    Vector3f k4v = (current.acceleration + k3v) * dt; // ���� k4 ���ٶ�����
    Vector3f k4p = (current.velocity + k3p) * dt;     // ���� k4 ��λ������

    // Final state
    Vector3f new_velocity = current.velocity + (k1v + 2.0f * k2v + 2.0f * k3v + k4v) / 6.0f;
    Vector3f new_position = current.position + (k1p + 2.0f * k2p + 2.0f * k3p + k4p) / 6.0f;

    KineticState next(new_position, new_velocity, current.acceleration);
    return next;
}

// Function to perform a single Backward Euler step
KineticState backward_euler_step([[maybe_unused]] const KineticState& previous,
                                 const KineticState& current)
{
    Vector3f new_velocity = current.velocity + current.acceleration * time_step;
    Vector3f new_position = current.position + new_velocity * time_step;

    KineticState next(new_position, new_velocity, current.acceleration);
    return next;
}

// Function to perform a single Symplectic Euler step
KineticState symplectic_euler_step([[maybe_unused]] const KineticState& previous,
                                   const KineticState& current)
{
    Vector3f new_velocity = current.velocity + current.acceleration * time_step;
    Vector3f new_position = current.position + new_velocity * time_step;

    KineticState next(new_position, new_velocity, current.acceleration);
    return next;
}
